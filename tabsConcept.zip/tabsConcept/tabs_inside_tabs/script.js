$(document).ready(() => {
    $(".search_class").on("keyup", function() {
        var value = $(this).val();
    
        $("table tr").each(function (index) {
            if (!index) return;
            $(this).find("td").each(function () {
                var id = $(this).text().toLowerCase().trim();
                var not_found = (id.indexOf(value) == -1);
                $(this).closest('tr').toggle(!not_found);
                return not_found;
            });
        });
    });
  
    
    $(".filter_logo").on("click", function(){

        $(".filter_content").fadeToggle();
    });
    $(".parent_flex .close").on("click", function(){
        $(".filter_content").fadeOut();
    });
   
    $(".customer_sort").click(() => {
        $(".sort_right li").hide();
        $("#customer_sort").show();
    });
    $(".vehicle_sort").click(() => {
        $(".sort_right li").hide();
        $("#vehicle_sort").show();
    });
    $(".lr_sort").click(() => {
        $(".sort_right li").hide();
        $("#lr_sort").show();
    });
    $(".from_sort").click(() => {
        $(".sort_right li").hide();
        $("#from_sort").show();
    });
    $(".to_sort").click(() => {
        $(".sort_right li").hide();
        $("#to_sort").show();
    });
    $(".loop_sort").click(() => {
        $(".sort_right li").hide();
        $("#loop_sort").show();
    });

    $('#Vehicle').easyResponsiveTabs({
        type: 'default',
        width: 'auto',
        fit: true,
        tabidentify: 'hor_1',
        activate: function (event) {
            var $tab = $(this);
            var $info = $('#nested-tabInfo');
            var $name = $('span', $info);
            $name.text($tab.text());
            $info.show();
        }
    });
    $('#Vtrip').easyResponsiveTabs({
        type: 'default',
        width: 'auto',
        fit: true,
        tabidentify: 'hor_2',
        activate: function (event) {
            var $tab = $(this);
            var $info = $('#nested-tabInfo1');
            var $name = $('span', $info);
            $name.text($tab.text());
            $info.show();
        }
    });
    $('#Transport').easyResponsiveTabs({
        type: 'default',
        width: 'auto',
        fit: true,
        tabidentify: 'hor_3',
        activate: function (event) {
            var $tab = $(this);
            var $info = $('#nested-tabInfo1');
            var $name = $('span', $info);
            $name.text($tab.text());
            $info.show();
        }
    });
});
! function (a) {
    a.fn.extend({
        easyResponsiveTabs: function (b) {
            var c = {
                    type: "default",
                    width: "auto",
                    fit: !0,
                    closed: !1,
                    tabidentify: "",
                    activetab_bg: "none",
                    inactive_bg: "#F5F5F5",
                    active_border_color: "#c1c1c1",
                    active_content_border_color: "#c1c1c1",
                    activate: function () {}
                },
                b = a.extend(c, b),
                d = b,
                e = d.type,
                f = d.fit,
                g = d.width,
                h = "vertical",
                i = "accordion",
                j = window.location.hash,
                k = !(!window.history || !history.replaceState);
            a(this).bind("tabactivate", function (a, c) {
                "function" == typeof b.activate && b.activate.call(c, a)
            }), this.each(function () {
                function m() {
                    e == h && c.addClass("resp-vtabs").addClass(b.tabidentify), 1 == f && c.css({
                        width: "100%",
                        margin: "0px"
                    }), e == i && (c.addClass("resp-easy-accordion").addClass(b.tabidentify), c.find(".resp-tabs-list").css("display", "none"))
                }
                var c = a(this),
                    d = c.find("ul.resp-tabs-list." + b.tabidentify),
                    l = c.attr("id");
                c.find("ul.resp-tabs-list." + b.tabidentify + " li").addClass("resp-tab-item").addClass(b.tabidentify), c.css({
                    display: "block",
                    width: g
                }), "vertical" == b.type && d.css("margin-top", "3px"), c.find(".resp-tabs-container." + b.tabidentify).css("border-color", b.active_content_border_color), c.find(".resp-tabs-container." + b.tabidentify + " > div").addClass("resp-tab-content").addClass(b.tabidentify), m();
                var n;
                c.find(".resp-tab-content." + b.tabidentify).before("<h2 class='resp-accordion " + b.tabidentify + "' role='tab'><span class='resp-arrow'></span></h2>"), c.find(".resp-tab-content." + b.tabidentify).prev("h2").css({
                    "background-color": b.inactive_bg,
                    "border-color": b.active_border_color
                });
                var o = 0;
                c.find(".resp-accordion").each(function () {
                    n = a(this);
                    var d = c.find(".resp-tab-item:eq(" + o + ")"),
                        e = c.find(".resp-accordion:eq(" + o + ")");
                    e.append(d.html()), e.data(d.data()), n.attr("aria-controls", b.tabidentify + "_tab_item-" + o), o++
                });
                var q, p = 0;
                c.find(".resp-tab-item").each(function () {
                    $tabItem = a(this), $tabItem.attr("aria-controls", b.tabidentify + "_tab_item-" + p), $tabItem.attr("role", "tab"), $tabItem.css({
                        "background-color": b.inactive_bg,
                        "border-color": "none"
                    });
                    var d = 0;
                    c.find(".resp-tab-content." + b.tabidentify).each(function () {
                        q = a(this), q.attr("aria-labelledby", b.tabidentify + "_tab_item-" + d).css({
                            "border-color": b.active_border_color
                        }), d++
                    }), p++
                });
                var r = 0;
                if ("" != j) {
                    var s = j.match(new RegExp(l + "([0-9]+)"));
                    null !== s && 2 === s.length && (r = parseInt(s[1], 10) - 1, r > p && (r = 0))
                }
                a(c.find(".resp-tab-item." + b.tabidentify)[r]).addClass("resp-tab-active").css({
                    "background-color": b.activetab_bg,
                    "border-color": b.active_border_color
                }), b.closed === !0 || "accordion" === b.closed && !d.is(":visible") || "tabs" === b.closed && d.is(":visible") || (a(c.find(".resp-accordion." + b.tabidentify)[r]).addClass("resp-tab-active").css({
                    "background-color": b.activetab_bg + " !important",
                    "border-color": b.active_border_color,
                    background: "none"
                }), a(c.find(".resp-tab-content." + b.tabidentify)[r]).addClass("resp-tab-content-active").addClass(b.tabidentify).attr("style", "display:block")), c.find("[role=tab]").each(function () {
                    var d = a(this);
                    d.click(function () {
                        var d = a(this),
                            e = d.attr("aria-controls");
                        if (d.hasClass("resp-accordion") && d.hasClass("resp-tab-active")) return c.find(".resp-tab-content-active." + b.tabidentify).slideUp("", function () {
                            a(this).addClass("resp-accordion-closed")
                        }), d.removeClass("resp-tab-active").css({
                            "background-color": b.inactive_bg,
                            "border-color": "none"
                        }), !1;
                        if (!d.hasClass("resp-tab-active") && d.hasClass("resp-accordion") ? (c.find(".resp-tab-active." + b.tabidentify).removeClass("resp-tab-active").css({
                                "background-color": b.inactive_bg,
                                "border-color": "none"
                            }), c.find(".resp-tab-content-active." + b.tabidentify).slideUp().removeClass("resp-tab-content-active resp-accordion-closed"), c.find("[aria-controls=" + e + "]").addClass("resp-tab-active").css({
                                "background-color": b.activetab_bg,
                                "border-color": b.active_border_color
                            }), c.find(".resp-tab-content[aria-labelledby = " + e + "]." + b.tabidentify).slideDown().addClass("resp-tab-content-active")) : (console.log("here"), c.find(".resp-tab-active." + b.tabidentify).removeClass("resp-tab-active").css({
                                "background-color": b.inactive_bg,
                                "border-color": "none"
                            }), c.find(".resp-tab-content-active." + b.tabidentify).removeAttr("style").removeClass("resp-tab-content-active").removeClass("resp-accordion-closed"), c.find("[aria-controls=" + e + "]").addClass("resp-tab-active").css({
                                "background-color": b.activetab_bg,
                                "border-color": b.active_border_color
                            }), c.find(".resp-tab-content[aria-labelledby = " + e + "]." + b.tabidentify).addClass("resp-tab-content-active").attr("style", "display:block")), d.trigger("tabactivate", d), k) {
                            var f = window.location.hash,
                                g = e.split("tab_item-"),
                                h = l + (parseInt(g[1], 10) + 1).toString();
                            if ("" != f) {
                                var i = new RegExp(l + "[0-9]+");
                                h = null != f.match(i) ? f.replace(i, h) : f + "|" + h
                            } else h = "#" + h;
                            history.replaceState(null, null, h)
                        }
                    })
                }), a(window).resize(function () {
                    c.find(".resp-accordion-closed").removeAttr("style")
                })
            })
        }
    })
}(jQuery);